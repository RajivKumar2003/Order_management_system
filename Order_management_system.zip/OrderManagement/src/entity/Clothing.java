package entity;

public class Clothing extends Product {
	private String size;
	private String color;
	
	public Clothing() {}
	public Clothing(int productID,String ProductName,String description,
            double price, int quantity, String size, String color) {
		super(productID,ProductName,description,price,quantity,"Clothing");
		this.size=size;
		this.color=color;
	}
}


