package entity;

public class Electronics extends Product {
	private String brand;
	private int warranty;
	
	public Electronics() {}
		public Electronics(int productID, String ProductName, String description,
                double price, int quantity, String brand, int warranty) {
			super(productID,ProductName,description,price,quantity,"Electronics");
			this.brand=brand;
			this.warranty=warranty;
			}
	}


