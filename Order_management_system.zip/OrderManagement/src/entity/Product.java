package entity;

public class Product {
	protected int productID;
	protected String ProductName;
	protected String description;
	protected double price;
	protected int quantity;
	protected String type;
	
	public Product() {}
		public Product(int productID,String ProductName,String description,double price,int quantity,String type) {
			this.productID=productID;
			this.ProductName=ProductName;
			this.description=description;
			this.price=price;
			this.quantity=quantity;
			this.type=type;
			
}
		public char[] getProductName() {
			// TODO Auto-generated method stub
			return null;
		}
		public void setProductId(int pid) {
			// TODO Auto-generated method stub
			
		}
}

