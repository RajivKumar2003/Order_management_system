package entity;

public class User {
	private int userID;
    private String username;
    private String password;
    private String role;
    
    public User(){}
    public User(int userID,String username,String password,String role) {
    	this.userID=userID;
    	this.username=username;
    	this.password=password;
    	this.role=role;
    }

}
