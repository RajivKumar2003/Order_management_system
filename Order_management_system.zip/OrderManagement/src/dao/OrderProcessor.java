package dao;

import entity.*;
import exception.*;

import java.sql.*;
import java.util.*;

public class OrderProcessor implements IOrderManagementRepository {
    public void createUser(User user) {
    }

    public void createProduct(User user, Product product) {
    }

    public void createOrder(User user, List<Product> products) {
    }

    public void cancelOrder(int userId, int orderId) {
    }

    public List<Product> getAllProducts() {
        return new ArrayList<>();
    }

    public List<Product> getOrderByUser(User user) {
        return new ArrayList<>();
    }
}