package main;

import dao.*;
import entity.*;
import java.util.*;

public class MainModule {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        IOrderManagementRepository repo = new OrderProcessor();
        
        while (true) {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Create User");
            System.out.println("2. Create Product");
            System.out.println("3. Create Order");
            System.out.println("4. Cancel Order");
            System.out.println("5. Get All Products");
            System.out.println("6. Get Orders by User");
            System.out.println("7. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            
            switch (choice) {
            case 1:
            	System.out.print("Enter User ID: ");
            	  System.out.print("Enter User ID: ");
                  int userId = scanner.nextInt();
                  scanner.nextLine();
                  System.out.print("Enter Username: ");
                  String username = scanner.nextLine();
                  System.out.print("Enter Password: ");
                  String password = scanner.nextLine();
                  System.out.print("Enter Role : ");
                  String role = scanner.nextLine();
                  User user = new User(userId, username, password, role);
                  repo.createUser(user);
                  System.out.println("User created successfully.");
                  break;
            case 2:
            	System.out.print("Enter Admin User ID: ");
                int adminId = scanner.nextInt();
                scanner.nextLine();
                User adminUser = new User(adminId, "", "", "Admin"); 
                System.out.print("Enter Product ID: ");
                int productId = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter Product Name: ");
                String productName = scanner.nextLine();
                System.out.print("Enter Description: ");
                String description = scanner.nextLine();
                System.out.print("Enter Price: ");
                double price = scanner.nextDouble();
                System.out.print("Enter Quantity: ");
                int quantity = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter Type (Electronics/Clothing): ");
                String type = scanner.nextLine();

                Product product = null;
                if (type.equalsIgnoreCase("Electronics")) {
                    System.out.print("Enter Brand: ");
                    String brand = scanner.nextLine();
                    System.out.print("Enter Warranty Period (months): ");
                    int warranty = scanner.nextInt();
                    scanner.nextLine();
                    product = new Electronics(productId, productName, description, price, quantity, brand, warranty);
                } else if (type.equalsIgnoreCase("Clothing")) {
                    System.out.print("Enter Size: ");
                    String size = scanner.nextLine();
                    System.out.print("Enter Color: ");
                    String color = scanner.nextLine();
                    product = new Clothing(productId, productName, description, price, quantity, size, color);
                }

                if (product != null) {
                    repo.createProduct(adminUser, product);
                    System.out.println("Product created successfully.");
                } else {
                    System.out.println("Invalid product type.");
                }
                break;
            case 3:
            	 System.out.print("Enter User ID: ");
                 int orderUserId = scanner.nextInt();
                 scanner.nextLine();
                 User orderUser = new User(orderUserId, "", "", "User");

                 List<Product> orderProducts = new ArrayList<>();
                 while (true) {
                     System.out.print("Enter Product ID to add to order (or -1 to finish): ");
                     int pid = scanner.nextInt();
                     if (pid == -1) break;
                     Product dummyProduct = new Product();
                     dummyProduct.setProductId(pid);
                     orderProducts.add(dummyProduct);
                 }

                 repo.createOrder(orderUser, orderProducts);
                 System.out.println("Order created successfully.");
                 break;
            case 4:
            	 System.out.print("Enter User ID: ");
                 int cancelUserId = scanner.nextInt();
                 System.out.print("Enter Order ID: ");
                 int cancelOrderId = scanner.nextInt();
                 try {
                     repo.cancelOrder(cancelUserId, cancelOrderId);
                     System.out.println("Order cancelled successfully.");
                 } catch (Exception e) {
                     System.out.println("Error: " + e.getMessage());
                 }
                 break;
            case 5:
            	List<Product> products = repo.getAllProducts();
                products.forEach(p -> System.out.println(p.getProductName()));
                break;
            case 6:
            	System.out.print("Enter User ID: ");
                int orderLookupUserId = scanner.nextInt();
                scanner.nextLine();
                User lookupUser = new User(orderLookupUserId, "", "", "User");
                List<Product> orderedProducts = repo.getOrderByUser(lookupUser);
                orderedProducts.forEach(p -> System.out.println(p.getProductName()));
                break;
            case 7:
                System.exit(0);
        }
    }
}
}

